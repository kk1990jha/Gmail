# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FormFor::Application.config.secret_token = '40a0c753261a7ea03f4de592900519d07b060b60dbc903dd2b4f673db26077393da814aa0184cb7807451e11b28dc91314f568e84945ce11cf225e3a4e312d76'
