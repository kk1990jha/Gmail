class AddColumnToWelcomes < ActiveRecord::Migration
  def self.up
	add_column :welcomes, :gender ,:string
  end

  def self.down
	remove_column :welcomes, :gender, :string
  end
end
