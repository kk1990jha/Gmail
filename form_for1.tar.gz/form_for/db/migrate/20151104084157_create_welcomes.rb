class CreateWelcomes < ActiveRecord::Migration
  def self.up
    create_table :welcomes do |t|
	t.string :fname
	t.string :lname
	t.string :username
	t.string :password
     # t.timestamps
    end
  end

  def self.down
    drop_table :welcomes
  end
end
