class Welcome < ActiveRecord::Base
end
