class WelcomesController < ApplicationController
  def index
    @data=Welcome.new
  end
  
  def create
     #raise params[:welcome].inspect
     @data=Welcome.new(params[:welcome])
     #raise @data.inspect
     @data.save
     redirect_to :action => 'show'
  end
  
  def show
    @data=Welcome.find(:all)
    #raise @data.inspect
  end
  
  def edit
    @data=Welcome.find_by_id(params[:Id])
    #raise @data.inspect
    #render :action => 'edit'
  end
  
  def update1
    #raise params.inspect
    @data=Welcome.find_by_id(params[:Id])
    #raise @data.inspect
    @data.update_attributes(:fname => !params[:welcomes][:fname].blank? ? params[:welcomes][:fname] : @data.fname,
    :lname => !params[:welcomes][:lname].blank? ? params[:welcomes][:lname] : @data.lname,
    :username => !params[:welcomes][:username].blank? ? params[:welcomes][:username] : @data.username,
    :password => !params[:welcomes][:password].blank? ? params[:welcomes][:password] : @data.password,
    :gender => !params[:welcomes][:gender].blank? ? params[:welcomes][:gender] : @data.gender)
     #raise @data.inspect
    @data.save
    redirect_to :action => 'show'
  end
  
  def delete
    @data=Welcome.find_by_id(params[:Id])
    @data.destroy
    redirect_to :action => 'show'
  end
end
